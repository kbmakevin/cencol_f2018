package com.cencol.kevinma_comp304lab2_ex1;

import android.os.Bundle;
import android.widget.Toast;

public class FoodTypesActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_types);
    }
}
